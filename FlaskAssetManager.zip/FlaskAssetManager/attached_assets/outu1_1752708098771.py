import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import json
import uuid
import random
import string
import os
import threading
import time

class FileGeneratorThread(threading.Thread):
    def __init__(self, id_value, copyid_value, author_value, item_name, start_result_id, callback):
        super().__init__()
        self.id_value = id_value
        self.copyid_value = copyid_value
        self.author_value = author_value
        self.item_name = item_name
        self.start_result_id = start_result_id  # New parameter for result_id
        self.callback = callback
        self.daemon = True
        
    def run(self):
        time.sleep(0.5)
        
        random_filename = ''.join(random.choices(string.digits, k=10))
        uuid_value = str(uuid.uuid4())
        
        # Main mod file
        main_mod_data = {
            "PhysicsActor": [],
            "avatarInfo": [],
            "foreign_ids": [],
            "mod_desc": {
                "author": self.author_value,
                "filename": random_filename,
                "uuid": uuid_value,
                "version": "1"
            },
            "property": {
                "copyid": self.copyid_value,
                "id": self.id_value
            },
            "set_ai": [{"name": "swimming", "priority": 1}]
        }
        
        # Ride file
        ride_data = {
            "property": {
                "id": self.id_value,
                "copyid": self.copyid_value
            }
        }
        
        # Crafting file
        crafting_data = {
            "PhysicsActor": [],
            "avatarInfo": [],
            "foreign_ids": [
                {
                    "id": self.start_result_id, # Updated id
                    "key": f"{self.author_value}{uuid_value.replace('-', '')}{random_filename}"
                }
            ],
            "mod_desc": {
                "author": self.author_value,
                "filename": ''.join(random.choices(string.digits, k=10)),
                "uuid": uuid_value,
                "version": "1"
            },
            "property": {
                "CraftingItemID": 11000,
                "copyid": self.copyid_value,
                "id": self.start_result_id + 1, # Updated id
                "material_count1": 1,
                "material_count2": 0,
                "material_count3": 0,
                "material_count4": 0,
                "material_count5": 0,
                "material_count6": 0,
                "material_count7": 0,
                "material_count8": 0,
                "material_count9": 0,
                "material_id1": 101,
                "material_id2": 0,
                "material_id3": 0,
                "material_id4": 0,
                "material_id5": 0,
                "material_id6": 0,
                "material_id7": 0,
                "material_id8": 0,
                "material_id9": 0,
                "result_count": 1,
                "result_id": self.start_result_id, # Updated result_id
                "type": 0
            }
        }
        
        # Item file
        item_data = {
            "PhysicsActor": {
                "EditType": 2,
                "ModelScale": 1,
                "ShapeID": 0,
                "ShapeVal1": 50,
                "ShapeVal2": 0,
                "ShapeVal3": 0
            },
            "avatarInfo": [],
            "foreign_ids": [
                {
                    "id": self.start_result_id, # Updated id
                    "key": f"{self.author_value}{uuid_value.replace('-', '')}{random_filename}"
                }
            ],
            "itemskills": [
                {
                    "ChargeTime": 1.5,
                    "ChargeType": 0,
                    "Cooldown": 5,
                    "Costs": [
                        {
                            "CostTarget": 10100,
                            "CostType": 1,
                            "CostVal": 0
                        }
                    ],
                    "Functions": [
                        {
                            "CallNum": 1,
                            "Duration": 0,
                            "IsFollow": 0,
                            "MobID": self.id_value
                        }
                    ],
                    "RangeType": 0,
                    "RangeVal1": 1000,
                    "RangeVal2": 300,
                    "RangeVal3": 300,
                    "SkillType": 1,
                    "TargetCamp": 0,
                    "name": "feature_call_monster",
                    "priority": 0,
                    "templateid": 103
                }
            ],
            "mod_desc": {
                "author": self.author_value,
                "filename": ''.join(random.choices(string.digits, k=10)),
                "uuid": uuid_value,
                "version": "1"
            },
            "property": {
                "copyid": 10100,
                "describe": "",
                "icon": "*11653",  # Changed to *11653
                "id": self.start_result_id, # Updated id
                "model": "*11653", # Changed to *11653
                "name": self.item_name,
                "orignid": self.start_result_id, # Updated orignid
                "stack_max": 1
            }
        }
        
        generated_files = {
            f"{self.copyid_value}du.json": (json.dumps(main_mod_data, indent=2, ensure_ascii=False), "actor"),
            f"{self.copyid_value}duride.json": (json.dumps(ride_data, indent=2, ensure_ascii=False), "horse"),
            f"craft{self.copyid_value}.json": (json.dumps(crafting_data, indent=2, ensure_ascii=False), "crafting"),
            f"item{self.copyid_value}.json": (json.dumps(item_data, indent=2, ensure_ascii=False), "item")
        }
        
        result_data = {
            'files': generated_files,
            'uuid': uuid_value,
            'random_filename': random_filename,
            'id': self.id_value,
            'copyid': self.copyid_value,
            'author': self.author_value,
            'item_name': self.item_name,
            'result_id_used': self.start_result_id # Return the result_id used
        }
        
        self.callback(result_data)

class CompactModGenerator:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Mini World Mod Generator")
        self.root.geometry("480x500") # Increased height for new button
        self.root.resizable(False, False)
        
        self.save_location = os.path.expanduser("~/Desktop")
        self.creature_data = self.load_creature_data()
        self.creature_groups = self.group_creatures_by_level()
        self.auto_id_counter = 2
        self.auto_result_id_counter = 4097  # New counter for result_id
        self.last_generated_files = [] # To store paths of the most recently generated files
        self.setup_ui()
        
    def load_creature_data(self):
        """Load creature data from the provided list"""
        data = """01|3430|Khủng Long Hóa Thạch Thường|3431|Khủng Long Hóa Thạch|3432|Khủng Long Hóa Thạch Siêu Cấp
02|3433|Sóc Bay Nhỏ|3434|Sóc Bay Nhanh Nhẹn|3435|Sóc Bay Láu Cá
03|3436|Kỳ Lân|3437|Thần Kỳ Lân|3438|Kỳ Lân May Mắn
04|3439|Chocobo|3440|Chocobo Thông Minh|3441|Chocobo Nghịch Ngợm
05|3442|Chú Voi Con|3443|Voi Vui Vẻ|3444|Voi Lễ Hội
06|3445|Sư Tử Biển Thủy Thủ|3446|Sư Tử Biển Thuyền Trưởng|3447|Boss Sư Tử Biển
07|3454|Mèo Thần Tài|3455|Mèo Phát Lộc|3456|Mèo Vũ Sư
08|3457|Bạch Mã|3458|Thiên Mã|3459|Thần Mã
09|3460|Kiệu Tre Cổ Điển|3461|Kiệu Vàng|3462|Kiệu Hoa Đào
10|3469|Mộc Long Thần|3470|Hỏa Long Thần|3471|Hắc Long Thần
11|3478|Trăng Rằm|3479|Trăng Ngọc|3480|Tiên Trăng
12|3483|Xe Tuần Lộc Gỗ|3484|Xe Tuần Lộc Vàng|3485|Xe Tuần Lộc Băng
13|3487|Pony Motor|||
14|3488|Bò May Mắn|||
15|3490|Transcendent Peak|3491|Ngọn Lửa Phương Bắc|3492|Chân Trời Trôi Dạt
16|3495|Bộ Bộ Liên Hoa|3496|Hoa Bay Tuyết Nhảy|3497|Kính Hoa Thủy Nguyệt
17|4501|Hươu Trắng Nhạt|4502|Sắc Màu Nirvana|4503|Vua Hươu
18|4505|Xe Bí Ngô Ma Thuật|4506|Xe Bí Ngô Hoàng Gia|4507|Xe Bí Ngô Cổ Tích
19|4509|Chong Chóng|4510|Xoắn Ốc Ba Lá|
20|4512|Thiên Nga Xám|4513|Thiên Nga Sao|4514|Thiên Nga Tiên
21|4517|Máy Bay Chiến Đấu|4518|Diều Hâu Đen|
22|4520|Cánh Phản Lực|4521|Diều Hâu Trắng|
23|4523|Bánh Xe Sấm Sét|||
24|4525|Boro Đại Dương|4526|Boro Đại Dương - Tiến Hóa|
25|4528|Seadrake|4529|Seadrake - Phát Triển|
26|4531|Rồng Đỏ Rực|4532|Rồng Vàng Kim|4533|Rồng Hư Không
27|4535|Nhạc Hội Petite|4536|Fluttering Shadow|
28|4539|Đêm Ả Rập|4540|Thảm Bay Ba Tư|4541|Thảm Ma Thuật Của Các Vì Sao
29|4543|Cúc Cu|4544|Kim Thuật Sư Quạ|4545|Chim Cắt Chiến Đấu
30|4547|Sóng Âm Mạnh Nhất|4548|Nhạc Điện Tử Vô Hạn|
31|4550|Hoa Trong Mây|4551|Vũ Điệu Hoa Yunmeng|
32|4553|Thủy Vân Du|4554|Túy Hoa Âm|
33|4556|Cún Mochi|||
34|4560|Hoàng Đế Colt Siêu Âm|4561|Hoàng Đế Colt Lục Hành|4562|Hoàng Đế Rồng
35|4564|Tiểu Hổ|4565|Hổ Con Xuống Núi|4566|Hổ Uy Phong
36|4572|Tinh Ngữ Tâm Nguyện|4573|Đèn Lồng|4574|Xuân Phong Yến Ngữ
37|4576|Thuyền Sa Mạc|4577|Sứ Giả Ốc Đảo|4578|Thần Lạc Hoa Lệ
38|4580|Giấc Mơ Hạnh Phúc|4581|Chân Dung|
39|4583|Chìa Khóa Trục Ảnh|4584|Chìa Khóa Mộng Li|4585|Chìa Khóa Vũ Huy
40|4587|Trường Kiếm Xích Tiêu|4588|Thánh Kiếm Hiên Viên|
41|4590|Thời Gian Thư Giãn|4591|Thời Khắc Trẻ Thơ|4592|Thời Khắc Mộng Ảo
42|4594|Tiểu Hồ Ly Đáng Yêu|4595|Hồ Ly Lanh Lợi|4596|Hồ Ly Ảo Ảnh
43|4598|Xe Mui Trần Mèo Yêu|||
44|4602|Sứ Giả Ốc Đảo|4603|Thần Lạc Hoa Lệ|
45|4606|Xanh Biếc|4607|Tử Dạ|4608|Thiều Quang
46|4610|Ánh Trăng Mật Ong|4611|Ngóng Nỗi Tương Tư|4612|Hoa Quế Trong Trăng
47|4614|Chuông Tím Buồn|4615|Hồn Bướm Dạo Mộng|4616|Lời Linh Lan Trong Gió
48|4618|Ván Lướt Sóng Phong|4619|Hành Động Phong Cực Hạn|
49|4623|Bé Heo|4624|Heo Bay Lô Lô|4625|Heo Cyberpunk
50|4628|Thỏ Ngọc Lưu Vân|4629|Thỏ Phúc Tới Nhà|
51|4632|Hộp Bột Mịn|4633|Hộp Cất Giữ Sao|4634|Đôi Cánh Giấc Mơ
52|4636|Tuyết Lưu Ly|4637|Băng Giá Nở Rộ|
53|4644|Xe Biến hình Mini|||
54|4646|Sách Lễ Mừng|||
55|4648|Thú Lộc Cộc|||
56|4650|Hương Bánh Đong Đưa|||
57|4654|Bồng Bềnh|||
58|4656|Ghế Tiểu Thư|||
59|4664|Âm Thanh Diệu Kỳ|4665|Hộp Nhạc Theo Đuổi Ngôi Sao|4666|Ngôi Sao Âm Nhạc
60|4668|Mầm Lá Ngọc|4669|Cành Du Dương|4670|Mộng Tuổi Thơ
61|4672|Vỏ Sò Lấp Lánh|4673|Giấc Mộng Phù Quang|4674|Ánh Sao San Hô
62|4682|Làn Mây Mộng Ảo|4683|Bóng Mộng Cảnh|4684|Làn Mây Tiên Cảnh"""
        
        creatures = {}
        for line in data.strip().split('\n'):
            parts = line.split('|')
            if len(parts) >= 3:
                # Parse each creature variant
                for i in range(1, len(parts), 2):
                    if i + 1 < len(parts) and parts[i] and parts[i+1]:
                        copy_id = int(parts[i])
                        name = parts[i+1]
                        creatures[copy_id] = name
        
        return creatures
    
    def group_creatures_by_level(self):
        """Group creatures by their base name and return the highest level for each"""
        data = """01|3430|Khủng Long Hóa Thạch Thường|3431|Khủng Long Hóa Thạch|3432|Khủng Long Hóa Thạch Siêu Cấp
02|3433|Sóc Bay Nhỏ|3434|Sóc Bay Nhanh Nhẹn|3435|Sóc Bay Láu Cá
03|3436|Kỳ Lân|3437|Thần Kỳ Lân|3438|Kỳ Lân May Mắn
04|3439|Chocobo|3440|Chocobo Thông Minh|3441|Chocobo Nghịch Ngợm
05|3442|Chú Voi Con|3443|Voi Vui Vẻ|3444|Voi Lễ Hội
06|3445|Sư Tử Biển Thủy Thủ|3446|Sư Tử Biển Thuyền Trưởng|3447|Boss Sư Tử Biển
07|3454|Mèo Thần Tài|3455|Mèo Phát Lộc|3456|Mèo Vũ Sư
08|3457|Bạch Mã|3458|Thiên Mã|3459|Thần Mã
09|3460|Kiệu Tre Cổ Điển|3461|Kiệu Vàng|3462|Kiệu Hoa Đào
10|3469|Mộc Long Thần|3470|Hỏa Long Thần|3471|Hắc Long Thần
11|3478|Trăng Rằm|3479|Trăng Ngọc|3480|Tiên Trăng
12|3483|Xe Tuần Lộc Gỗ|3484|Xe Tuần Lộc Vàng|3485|Xe Tuần Lộc Băng
13|3487|Pony Motor|||
14|3488|Bò May Mắn|||
15|3490|Transcendent Peak|3491|Ngọn Lửa Phương Bắc|3492|Chân Trời Trôi Dạt
16|3495|Bộ Bộ Liên Hoa|3496|Hoa Bay Tuyết Nhảy|3497|Kính Hoa Thủy Nguyệt
17|4501|Hươu Trắng Nhạt|4502|Sắc Màu Nirvana|4503|Vua Hươu
18|4505|Xe Bí Ngô Ma Thuật|4506|Xe Bí Ngô Hoàng Gia|4507|Xe Bí Ngô Cổ Tích
19|4509|Chong Chóng|4510|Xoắn Ốc Ba Lá|
20|4512|Thiên Nga Xám|4513|Thiên Nga Sao|4514|Thiên Nga Tiên
21|4517|Máy Bay Chiến Đấu|4518|Diều Hâu Đen|
22|4520|Cánh Phản Lực|4521|Diều Hâu Trắng|
23|4523|Bánh Xe Sấm Sét|||
24|4525|Boro Đại Dương|4526|Boro Đại Dương - Tiến Hóa|
25|4528|Seadrake|4529|Seadrake - Phát Triển|
26|4531|Rồng Đỏ Rực|4532|Rồng Vàng Kim|4533|Rồng Hư Không
27|4535|Nhạc Hội Petite|4536|Fluttering Shadow|
28|4539|Đêm Ả Rập|4540|Thảm Bay Ba Tư|4541|Thảm Ma Thuật Của Các Vì Sao
29|4543|Cúc Cu|4544|Kim Thuật Sư Quạ|4545|Chim Cắt Chiến Đấu
30|4547|Sóng Âm Mạnh Nhất|4548|Nhạc Điện Tử Vô Hạn|
31|4550|Hoa Trong Mây|4551|Vũ Điệu Hoa Yunmeng|
32|4553|Thủy Vân Du|4554|Túy Hoa Âm|
33|4556|Cún Mochi|||
34|4560|Hoàng Đế Colt Siêu Âm|4561|Hoàng Đế Colt Lục Hành|4562|Hoàng Đế Rồng
35|4564|Tiểu Hổ|4565|Hổ Con Xuống Núi|4566|Hổ Uy Phong
36|4572|Tinh Ngữ Tâm Nguyện|4573|Đèn Lồng|4574|Xuân Phong Yến Ngữ
37|4576|Thuyền Sa Mạc|4577|Sứ Giả Ốc Đảo|4578|Thần Lạc Hoa Lệ
38|4580|Giấc Mơ Hạnh Phúc|4581|Chân Dung|
39|4583|Chìa Khóa Trục Ảnh|4584|Chìa Khóa Mộng Li|4585|Chìa Khóa Vũ Huy
40|4587|Trường Kiếm Xích Tiêu|4588|Thánh Kiếm Hiên Viên|
41|4590|Thời Gian Thư Giãn|4591|Thời Khắc Trẻ Thơ|4592|Thời Khắc Mộng Ảo
42|4594|Tiểu Hồ Ly Đáng Yêu|4595|Hồ Ly Lanh Lợi|4596|Hồ Ly Ảo Ảnh
43|4598|Xe Mui Trần Mèo Yêu|||
44|4602|Sứ Giả Ốc Đảo|4603|Thần Lạc Hoa Lệ|
45|4606|Xanh Biếc|4607|Tử Dạ|4608|Thiều Quang
46|4610|Ánh Trăng Mật Ong|4611|Ngóng Nỗi Tương Tư|4612|Hoa Quế Trong Trăng
47|4614|Chuông Tím Buồn|4615|Hồn Bướm Dạo Mộng|4616|Lời Linh Lan Trong Gió
48|4618|Ván Lướt Sóng Phong|4619|Hành Động Phong Cực Hạn|
49|4623|Bé Heo|4624|Heo Bay Lô Lô|4625|Heo Cyberpunk
50|4628|Thỏ Ngọc Lưu Vân|4629|Thỏ Phúc Tới Nhà|
51|4632|Hộp Bột Mịn|4633|Hộp Cất Giữ Sao|4634|Đôi Cánh Giấc Mơ
52|4636|Tuyết Lưu Ly|4637|Băng Giá Nở Rộ|
53|4644|Xe Biến hình Mini|||
54|4646|Sách Lễ Mừng|||
55|4648|Thú Lộc Cộc|||
56|4650|Hương Bánh Đong Đưa|||
57|4654|Bồng Bềnh|||
58|4656|Ghế Tiểu Thư|||
59|4664|Âm Thanh Diệu Kỳ|4665|Hộp Nhạc Theo Đuổi Ngôi Sao|4666|Ngôi Sao Âm Nhạc
60|4668|Mầm Lá Ngọc|4669|Cành Du Dương|4670|Mộng Tuổi Thơ
61|4672|Vỏ Sò Lấp Lánh|4673|Giấc Mộng Phù Quang|4674|Ánh Sao San Hô
62|4682|Làn Mây Mộng Ảo|4683|Bóng Mộng Cảnh|4684|Làn Mây Tiên Cảnh"""
        
        creature_groups = {}
        for line in data.strip().split('\n'):
            parts = line.split('|')
            if len(parts) >= 3:
                group_id = parts[0]
                highest_level_id = None
                highest_level_name = None
                
                # Find the highest level (last non-empty creature in the group)
                # Iterate in steps of 2 starting from the second element (index 1) to get ID and Name pairs
                for i in range(1, len(parts), 2): 
                    if i + 1 < len(parts) and parts[i] and parts[i+1]:
                        # Ensure parts[i] is a valid integer before attempting conversion
                        if parts[i].isdigit(): 
                            highest_level_id = int(parts[i])
                            highest_level_name = parts[i+1]
                        
                if highest_level_id is not None and highest_level_name is not None:
                    creature_groups[group_id] = {
                        'copy_id': highest_level_id,
                        'name': highest_level_name
                    }
        
        return creature_groups
    
    def setup_ui(self):
        # Main frame
        main = tk.Frame(self.root, padx=15, pady=15)
        main.pack(fill=tk.BOTH, expand=True)
        
        # Bind Ctrl+Z to increment_id_hotkey for the entire window
        self.root.bind("<Control-z>", self.increment_id_hotkey)
        self.root.bind("<Control-Z>", self.increment_id_hotkey) # For Shift+Z if Caps Lock is on

        # Title
        tk.Label(main, text="🎮 Mini World Mod Generator", font=("Arial", 14, "bold")).pack(pady=(0,15))
        
        # Form
        tk.Label(main, text="ID:", font=("Arial", 10)).pack(anchor=tk.W)
        self.id_var = tk.StringVar(value="2")
        tk.Entry(main, textvariable=self.id_var).pack(fill=tk.X, pady=(0,8))
        
        tk.Label(main, text="Thần Thú:", font=("Arial", 10)).pack(anchor=tk.W)
        self.creature_frame = tk.Frame(main)
        self.creature_frame.pack(fill=tk.X, pady=(0,8))
        
        # Combobox for creature selection
        creature_list = []
        for copy_id, name in sorted(self.creature_data.items()):
            creature_list.append(f"{copy_id} - {name}")
        
        self.creature_var = tk.StringVar()
        self.creature_combo = ttk.Combobox(self.creature_frame, textvariable=self.creature_var, 
                                          values=creature_list, state="readonly", width=50)
        self.creature_combo.pack(fill=tk.X)
        self.creature_combo.bind('<<ComboboxSelected>>', self.on_creature_select)
        
        tk.Label(main, text="Author:", font=("Arial", 10)).pack(anchor=tk.W)
        self.author_var = tk.StringVar(value="1024277122")
        tk.Entry(main, textvariable=self.author_var).pack(fill=tk.X, pady=(0,15))
        
        # Display selected creature info - CREATE THIS BEFORE SETTING DEFAULT SELECTION
        self.info_frame = tk.Frame(main, relief=tk.SUNKEN, bd=1, bg="#f0f0f0")
        self.info_frame.pack(fill=tk.X, pady=(0,10))
        
        self.info_label = tk.Label(self.info_frame, text="", font=("Arial", 9), bg="#f0f0f0", 
                                  wraplength=380, justify=tk.LEFT)
        self.info_label.pack(padx=10, pady=5)
        
        # NOW set default selection after info_label is created
        if creature_list:
            self.creature_combo.set(creature_list[25])  # Default to Rồng Hư Không
            self.on_creature_select()
        
        # Buttons
        btn_frame = tk.Frame(main)
        btn_frame.pack(fill=tk.X, pady=(0,10))
        
        self.gen_btn = tk.Button(btn_frame, text="🚀 Tạo Files", bg="#4CAF50", fg="white", 
                                font=("Arial", 10, "bold"), command=self.generate_files)
        self.gen_btn.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0,5))
        
        self.auto_btn = tk.Button(btn_frame, text="🤖 Auto", bg="#2196F3", fg="white", 
                                 font=("Arial", 10, "bold"), command=self.auto_generate_all)
        self.auto_btn.pack(side=tk.LEFT, padx=(0,5))
        # Bind right-click to the auto button for reset functionality
        self.auto_btn.bind("<Button-3>", self.reset_auto_counters)
        
        tk.Button(btn_frame, text="📁", command=self.choose_folder).pack(side=tk.RIGHT)

        # Delete button
        self.delete_btn = tk.Button(main, text="🗑️ Xóa Files Cuối", bg="#F44336", fg="white", 
                                    font=("Arial", 10, "bold"), command=self.delete_latest_files, state=tk.DISABLED)
        self.delete_btn.pack(fill=tk.X, pady=(5,10))
        
        # Location
        self.loc_label = tk.Label(main, text=f"📍 {os.path.basename(self.save_location)}", 
                                 font=("Arial", 8), fg="gray")
        self.loc_label.pack()
        
        # Status
        self.status_label = tk.Label(main, text="Sẵn sàng", font=("Arial", 9), fg="green")
        self.status_label.pack(pady=(10,0))
        
    def on_creature_select(self, event=None):
        """Handle creature selection"""
        selected = self.creature_var.get()
        if selected:
            copy_id = int(selected.split(' - ')[0])
            name = self.creature_data[copy_id]
            self.info_label.config(text=f"Copy ID: {copy_id}\nTên Item: {name}")
            
    def get_selected_creature(self):
        """Get the selected creature's copy ID and name"""
        selected = self.creature_var.get()
        if selected:
            copy_id = int(selected.split(' - ')[0])
            name = self.creature_data[copy_id]
            return copy_id, name
        return None, None
        
    def choose_folder(self):
        folder = filedialog.askdirectory(initialdir=self.save_location)
        if folder:
            self.save_location = folder
            self.loc_label.config(text=f"📍 {os.path.basename(folder)}")
            
    def generate_files(self):
        try:
            id_value = int(self.id_var.get())
            author_value = self.author_var.get()
            copyid_value, item_name = self.get_selected_creature()
            
            if not author_value:
                raise ValueError("Nhập tác giả")
            
            if not copyid_value:
                raise ValueError("Chọn thần thú")
            
            self.gen_btn.config(text="⏳ Đang tạo...", state=tk.DISABLED)
            self.status_label.config(text="Đang xử lý...", fg="orange")

            # Clear last generated files before starting a new single generation
            self.last_generated_files = []
            self.delete_btn.config(state=tk.DISABLED)
            
            # Use current auto_result_id_counter for single generation
            thread = FileGeneratorThread(id_value, copyid_value, author_value, item_name, 
                                         self.auto_result_id_counter, self.on_complete)
            thread.start()
            # Increment result_id_counter by 2 for the next potential generation
            self.auto_result_id_counter += 2 
            
        except ValueError as e:
            messagebox.showerror("Lỗi", str(e))
            self.gen_btn.config(text="🚀 Tạo Files", state=tk.NORMAL) # Re-enable if error
            self.status_label.config(text="Sẵn sàng", fg="green") # Reset status
            
    def on_complete(self, data):
        self.root.after(0, lambda: self.write_files(data))
        
    def write_files(self, data):
        try:
            created_current_session = []
            
            for filename, (content, folder) in data['files'].items():
                folder_path = os.path.join(self.save_location, folder)
                os.makedirs(folder_path, exist_ok=True)
                
                file_path = os.path.join(folder_path, filename)
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                created_current_session.append(f"{folder_path}/{filename}") # Store full path

            self.last_generated_files = created_current_session # Update list of last created files
            self.delete_btn.config(state=tk.NORMAL) # Enable delete button
            
            self.gen_btn.config(text="🚀 Tạo Files", state=tk.NORMAL)
            self.status_label.config(text=f"✅ Tạo {len(created_current_session)} files thành công! (Result ID cuối: {data['result_id_used']})", fg="green")
            
            messagebox.showinfo("Thành công", 
                              f"Đã tạo {len(created_current_session)} files cho {data['item_name']}:\n" + 
                              "\n".join([os.path.basename(f) for f in created_current_session]))
            
        except Exception as e:
            self.gen_btn.config(text="🚀 Tạo Files", state=tk.NORMAL)
            self.status_label.config(text="❌ Lỗi tạo files", fg="red")
            messagebox.showerror("Lỗi", f"Không thể tạo files: {str(e)}")
    
    def auto_generate_all(self):
        """Automatically generate files for all creatures at their highest level"""
        if not messagebox.askyesno("Xác nhận", 
                                  f"Bạn có muốn tạo files cho tất cả {len(self.creature_groups)} thần thú?\n"
                                  f"ID bắt đầu từ: {self.auto_id_counter}\n"
                                  f"Result ID bắt đầu từ: {self.auto_result_id_counter}\n"
                                  f"Files sẽ được tạo trực tiếp trong các thư mục tương ứng, không tạo thư mục 'auto_generated'."):
            return
        
        self.auto_btn.config(text="⏳ Đang tạo...", state=tk.DISABLED)
        self.gen_btn.config(state=tk.DISABLED)
        self.delete_btn.config(state=tk.DISABLED)

        # Clear last generated files before starting a new auto-generation batch
        self.last_generated_files = []
        
        # Create a thread for auto generation
        auto_thread = threading.Thread(target=self.auto_generate_worker, daemon=True)
        auto_thread.start()
    
    def auto_generate_worker(self):
        """Worker thread for auto generation"""
        try:
            author_value = self.author_var.get()
            if not author_value:
                raise ValueError("Nhập tác giả")
            
            total_creatures = len(self.creature_groups)
            current_id = self.auto_id_counter
            current_result_id = self.auto_result_id_counter # Use a local copy for the loop
            success_count = 0
            
            for group_id, creature_info in sorted(self.creature_groups.items()):
                try:
                    # Update status
                    self.root.after(0, lambda name=creature_info['name'], res_id=current_result_id: self.status_label.config(
                        text=f"⏳ Đang tạo {success_count + 1}/{total_creatures}: {name} (Result ID: {res_id})", 
                        fg="orange"))
                    
                    # Generate files for this creature
                    thread = FileGeneratorThread(
                        current_id, 
                        creature_info['copy_id'], 
                        author_value, 
                        creature_info['name'], 
                        current_result_id, # Pass the current result_id
                        self.auto_write_files_callback # Use a specific callback for auto-gen
                    )
                    thread.start()
                    thread.join()  # Wait for completion
                    
                    success_count += 1
                    current_id += 1
                    current_result_id += 2 # Increment result_id by 2 for the next creature
                    
                    # Small delay between generations
                    time.sleep(0.1)
                    
                except Exception as e:
                    print(f"Error generating files for {creature_info['name']}: {str(e)}")
                    continue
            
            # Update counters for next time
            self.auto_id_counter = current_id
            self.auto_result_id_counter = current_result_id
            
            # Update UI on completion
            self.root.after(0, lambda: self.auto_complete(success_count, total_creatures))
            
        except Exception as e:
            self.root.after(0, lambda: self.auto_error(str(e)))
    
    def auto_write_files_callback(self, data):
        """Callback to write files during auto-generation, appends to last_generated_files."""
        try:
            for filename, (content, folder) in data['files'].items():
                folder_path = os.path.join(self.save_location, folder) # Direct path, no "auto_generated"
                os.makedirs(folder_path, exist_ok=True)
                
                file_path = os.path.join(folder_path, filename)
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                self.last_generated_files.append(file_path) # Append to central list
                    
        except Exception as e:
            print(f"Error writing files in auto-generation for {data.get('item_name', 'unknown')}: {str(e)}")
    
    def auto_complete(self, success_count, total_creatures):
        """Handle auto generation completion"""
        self.auto_btn.config(text="🤖 Auto", state=tk.NORMAL)
        self.gen_btn.config(state=tk.NORMAL)
        self.delete_btn.config(state=tk.NORMAL) # Enable delete button after auto-gen
        
        if success_count == total_creatures:
            self.status_label.config(
                text=f"✅ Tạo thành công {success_count}/{total_creatures} thần thú! (Result ID tiếp theo: {self.auto_result_id_counter})", 
                fg="green"
            )
            messagebox.showinfo("Hoàn thành", 
                              f"Đã tạo thành công {success_count} thần thú!\n"
                              f"Files được lưu trực tiếp trong thư mục đã chọn: {os.path.basename(self.save_location)}/[actor|horse|crafting|item]/\n"
                              f"ID tiếp theo sẽ bắt đầu từ: {self.auto_id_counter}\n"
                              f"Result ID tiếp theo sẽ bắt đầu từ: {self.auto_result_id_counter}")
        else:
            self.status_label.config(
                text=f"⚠️ Tạo được {success_count}/{total_creatures} thần thú (Result ID tiếp theo: {self.auto_result_id_counter})", 
                fg="orange"
            )
            messagebox.showwarning("Hoàn thành một phần", 
                                 f"Đã tạo được {success_count}/{total_creatures} thần thú!\n"
                                 f"Một số thần thú có thể bị lỗi.\n"
                                 f"Files được lưu trực tiếp trong thư mục đã chọn: {os.path.basename(self.save_location)}/[actor|horse|crafting|item]/\n"
                                 f"Result ID tiếp theo sẽ bắt đầu từ: {self.auto_result_id_counter}")
    
    def auto_error(self, error_msg):
        """Handle auto generation error"""
        self.auto_btn.config(text="🤖 Auto", state=tk.NORMAL)
        self.gen_btn.config(state=tk.NORMAL)
        self.delete_btn.config(state=tk.DISABLED) # Keep delete disabled if no files created
        self.status_label.config(text="❌ Lỗi tạo auto", fg="red")
        messagebox.showerror("Lỗi", f"Lỗi tạo auto: {error_msg}")

    def reset_auto_counters(self, event):
        """
        Resets the auto ID and Result ID counters to their default values.
        Triggered by right-clicking the 'Auto' button.
        """
        if messagebox.askyesno("Xác nhận Reset", 
                               "Bạn có chắc chắn muốn reset ID và Result ID về giá trị mặc định không?\n"
                               "ID mặc định: 2\n"
                               "Result ID mặc định: 4097"):
            self.auto_id_counter = 2
            self.auto_result_id_counter = 4097
            self.status_label.config(text="✅ Đã reset ID và Result ID về mặc định.", fg="green")
            messagebox.showinfo("Reset thành công", "ID và Result ID đã được reset về mặc định.")
        else:
            self.status_label.config(text="Sẵn sàng", fg="green") # Reset status if cancelled

    def delete_latest_files(self):
        """Delete files created in the most recent generation."""
        if not self.last_generated_files:
            messagebox.showinfo("Thông báo", "Không có file nào để xóa từ lần tạo gần nhất.")
            return

        if not messagebox.askyesno("Xác nhận xóa", 
                                  f"Bạn có chắc chắn muốn xóa {len(self.last_generated_files)} file được tạo gần nhất không?"):
            return

        deleted_count = 0
        failed_deletes = []
        for file_path in self.last_generated_files:
            try:
                if os.path.exists(file_path):
                    os.remove(file_path)
                    deleted_count += 1
                else:
                    print(f"File không tồn tại: {file_path}") # For debugging
            except Exception as e:
                failed_deletes.append(f"{os.path.basename(file_path)}: {e}")
        
        self.last_generated_files = [] # Clear the list after attempting deletion
        self.delete_btn.config(state=tk.DISABLED) # Disable button after deletion

        if not failed_deletes:
            self.status_label.config(text=f"✅ Đã xóa {deleted_count} file gần nhất thành công.", fg="green")
            messagebox.showinfo("Xóa thành công", f"Đã xóa {deleted_count} file được tạo gần nhất.")
        else:
            self.status_label.config(text=f"⚠️ Đã xóa {deleted_count} file, nhưng có lỗi với {len(failed_deletes)} file.", fg="orange")
            messagebox.showwarning("Xóa một phần thành công", 
                                 f"Đã xóa {deleted_count} file được tạo gần nhất, nhưng có lỗi với các file sau:\n" + 
                                 "\n".join(failed_deletes))

    def increment_id_hotkey(self, event=None):
        """Increments the ID value by 1 when Ctrl+Z is pressed."""
        try:
            current_id = int(self.id_var.get())
            new_id = current_id + 1
            self.id_var.set(str(new_id))
            self.status_label.config(text=f"ID đã tăng lên: {new_id}", fg="blue")
        except ValueError:
            self.status_label.config(text="❌ ID không hợp lệ, không thể tăng.", fg="red")
        except Exception as e:
            self.status_label.config(text=f"❌ Lỗi khi tăng ID: {e}", fg="red")
            print(f"Error incrementing ID: {e}")

            
    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = CompactModGenerator()
    app.run()
